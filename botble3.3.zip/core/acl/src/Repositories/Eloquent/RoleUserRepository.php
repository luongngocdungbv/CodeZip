<?php

namespace Botble\ACL\Repositories\Eloquent;

use Botble\ACL\Repositories\Interfaces\RoleUserInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class RoleUserRepository extends RepositoriesAbstract implements RoleUserInterface
{
}
